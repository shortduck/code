/**
 * ExpenseException
 * 
 * Date 19 January, 2009
 * 
 * @Author SG
 */

package gov.michigan.dit.timeexpense.exception;

public class ExpenseException extends TimeAndExpenseException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExpenseException(){}
	
	public ExpenseException(String msg){
		super(msg);
		
	}
	
	public ExpenseException(String msg, Throwable cause){
		super(msg,cause);
		
	}

}
