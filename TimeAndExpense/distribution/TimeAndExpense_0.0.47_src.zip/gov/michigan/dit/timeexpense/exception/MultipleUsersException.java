package gov.michigan.dit.timeexpense.exception;

public class MultipleUsersException extends TimeAndExpenseException{

	private static final long serialVersionUID = -5886609256882373918L;

	public MultipleUsersException() {}
	
	public MultipleUsersException(String msg) {
		super(msg);
	}

	public MultipleUsersException(String code, String msg) {
		super(code, msg);
	}
	
	public MultipleUsersException(String msg, Throwable cause){
		super(msg, cause);
	}

}
