package gov.michigan.dit.timeexpense.model.core;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="DEPARTMENTS")
public class Department implements Serializable{
	
    private static final long serialVersionUID = 17003L;
    
    @Id
    private String department;
    
    private String name;

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
