package gov.michigan.dit.timeexpense.model.display;

public class AgencyMilesDisplay {
	
	String commonMiles;
	String milesDefinedAgency;
	public String getCommonMiles() {
		return commonMiles;
	}
	public void setCommonMiles(String commonMiles) {
		this.commonMiles = commonMiles;
	}
	public String getMilesDefinedAgency() {
		return milesDefinedAgency;
	}
	public void setMilesDefinedAgency(String milesDefinedAgency) {
		this.milesDefinedAgency = milesDefinedAgency;
	}

}
