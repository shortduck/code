package gov.michigan.dit.timeexpense.model.display;

import java.io.Serializable;

public class TravelRequisitionReportDisplayBean implements Serializable {

	private String name;
	private String officeProgram;
	private String requestDate; 
	private String desitination; 
	private String transportationVia;
	private String travelDates;
	private String empIdentifier; 
	private String natureOfBusiness; 
	private String advanceAmount; 
	private String transportationAmount;
	private String lodgingAmount;
	private String mealsAmount;
	private String registAmount;
	private String otherAmount;
	private String totalAmount;
	private String approvalName;
	private String outOfStateApprovalName;
	private String departmentName;
	private String treqIdentifier;
    private String outOfStateAuthCodes;
    private String versionNumber;
    private String airFareAmount;
    private String comments;
    

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	public String getOfficeProgram() {
		return officeProgram;
	}
	public void setOfficeProgram(String officeProgram) {
		this.officeProgram = officeProgram;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getDesitination() {
		return desitination;
	}
	public void setDesitination(String desitination) {
		this.desitination = desitination;
	}
	public String getTransportationVia() {
		return transportationVia;
	}
	public void setTransportationVia(String transportationVia) {
		this.transportationVia = transportationVia;
	}
	public String getTravelDates() {
		return travelDates;
	}
	public void setTravelDates(String travelDates) {
		this.travelDates = travelDates;
	}
	public String getEmpIdentifier() {
		return empIdentifier;
	}
	public void setEmpIdentifier(String empIdentifier) {
		this.empIdentifier = empIdentifier;
	}
	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}
	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}
	public String getAdvanceAmount() {
		return advanceAmount;
	}
	public void setAdvanceAmount(String advanceAmount) {
		this.advanceAmount = advanceAmount;
	}
	public String getTransportationAmount() {
		return transportationAmount;
	}
	public void setTransportationAmount(String transportationAmount) {
		this.transportationAmount = transportationAmount;
	}
	public String getLodgingAmount() {
		return lodgingAmount;
	}
	public void setLodgingAmount(String lodgingAmount) {
		this.lodgingAmount = lodgingAmount;
	}
	public String getMealsAmount() {
		return mealsAmount;
	}
	public void setMealsAmount(String mealsAmount) {
		this.mealsAmount = mealsAmount;
	}
	public String getRegistAmount() {
		return registAmount;
	}
	public void setRegistAmount(String registAmount) {
		this.registAmount = registAmount;
	}
	public String getOtherAmount() {
		return otherAmount;
	}
	public void setOtherAmount(String otherAmount) {
		this.otherAmount = otherAmount;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getApprovalName() {
		return approvalName;
	}
	public void setApprovalName(String approvalName) {
		this.approvalName = approvalName;
	}
	public String getOutOfStateApprovalName() {
		return outOfStateApprovalName;
	}
	public void setOutOfStateApprovalName(String outOfStateApprovalName) {
		this.outOfStateApprovalName = outOfStateApprovalName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getTreqIdentifier() {
		return treqIdentifier;
	}
	public void setTreqIdentifier(String treqIdentifier) {
		this.treqIdentifier = treqIdentifier;
	}
	public String getOutOfStateAuthCodes() {
		return outOfStateAuthCodes;
	}
	public void setOutOfStateAuthCodes(String outOfStateAuthCodes) {
		this.outOfStateAuthCodes = outOfStateAuthCodes;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getAirFareAmount() {
		return airFareAmount;
	}
	public void setAirFareAmount(String airFareAmount) {
		this.airFareAmount = airFareAmount;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}	
}	
