package gov.michigan.dit.timeexpense.model.display;

import java.io.Serializable;
import java.util.Date;

public class MyEmployeesListBean implements Serializable {

	private static final long serialVersionUID = -2989263766456488436L;
	
	private int employeeId;
	private int appointmentId;
	private Integer apptHistoryId;
	private Date appointmentStart;
	private Date appointmentEnd;
	private String department;
	private String agency;
	private String tku;
	private String firstName;
	private String middleName;
	private String lastName;
	private String nameSuffix;
	private String positionId;
	private Date departureDate;
	private Date appointmentDate;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public Integer getApptHistoryId() {
		return apptHistoryId;
	}
	public void setApptHistoryId(Integer apptHistoryId) {
		this.apptHistoryId = apptHistoryId;
	}
	public Date getAppointmentStart() {
		return appointmentStart;
	}
	public void setAppointmentStart(Date appointmentStart) {
		this.appointmentStart = appointmentStart;
	}
	public Date getAppointmentEnd() {
		return appointmentEnd;
	}
	public void setAppointmentEnd(Date appointmentEnd) {
		this.appointmentEnd = appointmentEnd;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public String getTku() {
		return tku;
	}
	public void setTku(String tku) {
		this.tku = tku;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getNameSuffix() {
		return nameSuffix;
	}
	public void setNameSuffix(String nameSuffix) {
		this.nameSuffix = nameSuffix;
	}
	public String getPositionId() {
		return positionId;
	}
	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}

}
