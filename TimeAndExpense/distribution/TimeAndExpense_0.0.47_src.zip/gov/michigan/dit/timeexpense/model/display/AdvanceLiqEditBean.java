/**
 * 
 */
package gov.michigan.dit.timeexpense.model.display;
import java.io.Serializable;

/**
 * @author chiduras
 *
 */
public class AdvanceLiqEditBean implements Serializable  {
	private static final long serialVersionUID = 3518524428959890130L; 

	
	private int advanceMasterId;
    private int advanceEventId;
	private String status;
	private String currentInd;
	
	public void setAdvanceMasterId(int advanceMasterId) {
		this.advanceMasterId = advanceMasterId;
	}
	public int getAdvanceMasterId() {
		return advanceMasterId;
	}
	public void setAdvanceEventId(int advanceEventId) {
		this.advanceEventId = advanceEventId;
	}
	public int getAdvanceEventId() {
		return advanceEventId;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setCurrentInd(String currentInd) {
		this.currentInd = currentInd;
	}
	public String getCurrentInd() {
		return currentInd;
	}
	  

}
