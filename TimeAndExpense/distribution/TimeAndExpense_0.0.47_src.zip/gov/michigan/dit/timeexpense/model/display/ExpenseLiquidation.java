package gov.michigan.dit.timeexpense.model.display;

import java.io.Serializable;
import java.util.List;

public class ExpenseLiquidation implements Serializable {
	
	private static final long serialVersionUID = 7495253814027597405L;

	private List<ExpenseLiquidationDisplay> liquidationList;

	public List<ExpenseLiquidationDisplay> getLiquidationList() {
		return liquidationList;
	}

	public void setLiquidationList(List<ExpenseLiquidationDisplay> liquidationList) {
		this.liquidationList = liquidationList;
	}
	
	

}
