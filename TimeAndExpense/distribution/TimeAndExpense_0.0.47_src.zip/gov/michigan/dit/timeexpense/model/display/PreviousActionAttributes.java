package gov.michigan.dit.timeexpense.model.display;

import gov.michigan.dit.timeexpense.model.core.UserSubject;

import java.io.Serializable;
import java.util.Map;

public class PreviousActionAttributes implements Serializable{
	private String moduleId = "";
	private EmployeeHeaderBean empInfo = null;
	private UserSubject userSubject = null;
	private Map parameterMap = null;
	private String actionName = "";
	
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}
	public String getModuleId() {
		return moduleId;
	}
	public void setEmpInfo(EmployeeHeaderBean empInfo) {
		this.empInfo = empInfo;
	}
	public EmployeeHeaderBean getEmpInfo() {
		return empInfo;
	}
	public void setUserSubject(UserSubject userSubject) {
		this.userSubject = userSubject;
	}
	public UserSubject getUserSubject() {
		return userSubject;
	}
	public void setParameterMap(Map parameterMap) {
		this.parameterMap = parameterMap;
	}
	public Map getParameterMap() {
		return parameterMap;
	}
	public void setActionName(String actionName) {
		this.actionName = actionName;
	}
	public String getActionName() {
		return actionName;
	}

}
