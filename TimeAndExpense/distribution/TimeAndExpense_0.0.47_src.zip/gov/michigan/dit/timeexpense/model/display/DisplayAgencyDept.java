package gov.michigan.dit.timeexpense.model.display;

public class DisplayAgencyDept {
	
	private String deptNum;
	private String agencyNum;
	private String agencyName;
	private String accessT;
	private String chosenDepartment;
	private String chosenAgency;
	private String identifierKey;
	private String select;
	private boolean writeAccess;
	private String mLval;
	private String aLval;
	private String agVal;
	
	
	/**
	 * @return writeAccess True/false
	 */
	public boolean getWriteAccess() {
		return writeAccess;
	}

	/**
	 * @param writeAccess
	 */
	public void setWriteAccess(boolean writeAccess) {
		this.writeAccess = writeAccess;
	}
	
	public String getSelect()
	{
		return select;
	}
	
	public void setSelect(String select)
	{
		this.select=select;
	}
	
	
	public String getIdentifierKey()
	{
		return identifierKey;
	}
	
	public void setIdentifierKey(String identifierKey)
	{
		this.identifierKey=identifierKey;
	}
	
	public void setChosenAgency(String chosenAgency)
	{
		this.chosenAgency = chosenAgency;
	}
	public String getChosenAgency()
	{
		return chosenAgency;
	}
	
	public void setChosenDepartment(String chosenDepartment)
	{
		this.chosenDepartment = chosenDepartment;
	}
	public String getChosenDepartment()
	{
		return chosenDepartment;
	}
	
	
	public void setDeptNum(String deptNum)
	{
		this.deptNum = deptNum;
	}
	public String setDeptNum( )
	{
		return deptNum;
	}
	public void setAgencyNum(String agencyNum)
	{
		this.agencyNum = agencyNum;
	}
	public String getAgencyNum( )
	{
		return agencyNum;
	}
	
	public void setAgencyName(String agencyName)
	{
		this.agencyName = agencyName;
	}
	public String getAgencyName()
	{
		return agencyName;
	}
	public void setAccessT(String accessT)
	{
		this.accessT = accessT;
	}
	public String setAccessT( )
	{
		return accessT;
	}

	public String getMLval() {
		return mLval;
	}

	public void setMLval(String lval) {
		mLval = lval;
	}

	public String getALval() {
		return aLval;
	}

	public void setALval(String lval) {
		aLval = lval;
	}

	public String getAgVal() {
		return agVal;
	}

	public void setAgVal(String agVal) {
		this.agVal = agVal;
	}

}
