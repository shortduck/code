/**
 * 
 */
package gov.michigan.dit.timeexpense.model.display;

import java.util.Date;

import javax.persistence.Column;

/**
 * @author chiduras
 *
 */

   
public class StandardDistCoding {

    private int dfdseIdentifier;
    private String appropriationYear;
    private String indexCode;
    private String pca;
    private String grantNumber;
    private String grantPhase;
    private String agencyCode1;
    private String projectNumber;
    private String projectPhase;
    private String agencyCode2;
    private String agencyCode3;
    private String multipurposeCode;
    private double percent;
    private Date startDate;
    private Date endDate;
    private String source;
    
    public String getAppropriationYear() {
        return appropriationYear;
    }
    public void setAppropriationYear(String appropriationYear) {
        this.appropriationYear = appropriationYear;
    }
    public String getIndexCode() {
        return indexCode;
    }
    public void setIndexCode(String indexCode) {
        this.indexCode = indexCode;
    }
    public String getPca() {
        return pca;
    }
    public void setPca(String pca) {
        this.pca = pca;
    }
    public String getGrantNumber() {
        return grantNumber;
    }
    public void setGrantNumber(String grantNumber) {
        this.grantNumber = grantNumber;
    }
    public String getGrantPhase() {
        return grantPhase;
    }
    public void setGrantPhase(String grantPhase) {
        this.grantPhase = grantPhase;
    }
    public String getAgencyCode1() {
        return agencyCode1;
    }
    public void setAgencyCode1(String agencyCode1) {
        this.agencyCode1 = agencyCode1;
    }
    public String getProjectNumber() {
        return projectNumber;
    }
    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }
    public String getProjectPhase() {
        return projectPhase;
    }
    public void setProjectPhase(String projectPhase) {
        this.projectPhase = projectPhase;
    }
    public String getAgencyCode2() {
        return agencyCode2;
    }
    public void setAgencyCode2(String agencyCode2) {
        this.agencyCode2 = agencyCode2;
    }
    public String getAgencyCode3() {
        return agencyCode3;
    }
    public void setAgencyCode3(String agencyCode3) {
        this.agencyCode3 = agencyCode3;
    }
    public String getMultipurposeCode() {
        return multipurposeCode;
    }
    public void setMultipurposeCode(String multipurposeCode) {
        this.multipurposeCode = multipurposeCode;
    }
    public double getPercent() {
        return percent;
    }
    public void setPercent(double percent) {
        this.percent = percent;
    }
    public Date getEndDate() {
        return endDate;
    }
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    public Date getStartDate() {
        return startDate;
    }
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    public void setDfdseIdentifier(int dfdseIdentifier) {
	this.dfdseIdentifier = dfdseIdentifier;
    }
    public int getDfdseIdentifier() {
	return dfdseIdentifier;
    }
    public void setSource(String source) {
	this.source = source;
    }
    public String getSource() {
	return source;
    }

   
 
    
    
    
}
