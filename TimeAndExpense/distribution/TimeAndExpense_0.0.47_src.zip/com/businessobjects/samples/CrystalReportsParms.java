package com.businessobjects.samples;

/**
 * CR credential class.
 * 
 * @author evanis
 */
public class CrystalReportsParms {

	private String user;
	private String password;
	private String connectionUrl;
	private String dbDriver;
	private String jndiName;
	private String reportsLocation;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getConnectionUrl() {
		return connectionUrl;
	}

	public void setConnectionUrl(String connectionUrl) {
		this.connectionUrl = connectionUrl;
	}

	public String getDbDriver() {
		return dbDriver;
	}

	public void setDbDriver(String dbDriver) {
		this.dbDriver = dbDriver;
	}

	public String getJndiName() {
		return jndiName;
	}

	public void setJndiName(String jndiName) {
		this.jndiName = jndiName;
	}

	public String getReportsLocation() {
		return reportsLocation;
	}

	public void setReportsLocation(String reportsLocation) {
		this.reportsLocation = reportsLocation;
	}
}


